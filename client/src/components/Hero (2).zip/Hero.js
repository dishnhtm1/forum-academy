import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import heroImage from '../assets/student/hero3.jpg';

const Hero = () => {
    const { t } = useTranslation();
    const [isVisible, setIsVisible] = useState(false);
    const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
    const [currentTech, setCurrentTech] = useState(0);
    
    const techTags = [
        { name: t('hero.techTags.webDevelopment') || 'Web Development', icon: '💻', color: 'from-blue-400 to-blue-600' },
        { name: t('hero.techTags.cybersecurity') || 'Cybersecurity', icon: '🔒', color: 'from-purple-400 to-purple-600' },
        { name: t('hero.techTags.dataScience') || 'Data Science', icon: '📊', color: 'from-pink-400 to-pink-600' },
        { name: t('hero.techTags.cloudComputing') || 'Cloud Computing', icon: '☁️', color: 'from-green-400 to-green-600' },
        { name: t('hero.techTags.ai') || 'AI & ML', icon: '🤖', color: 'from-indigo-400 to-indigo-600' },
        { name: t('hero.techTags.mobile') || 'Mobile Dev', icon: '📱', color: 'from-orange-400 to-orange-600' }
    ];
    
    useEffect(() => {
        const timer = setTimeout(() => {
            setIsVisible(true);
        }, 100);
        
        // Mouse movement for parallax effect
        const handleMouseMove = (e) => {
            setMousePosition({
                x: (e.clientX / window.innerWidth) * 100,
                y: (e.clientY / window.innerHeight) * 100
            });
        };
        
        // Tech tag rotation
        const techInterval = setInterval(() => {
            setCurrentTech((prev) => (prev + 1) % techTags.length);
        }, 3000);
        
        window.addEventListener('mousemove', handleMouseMove);
        
        // Create floating elements
        const createFloatingElements = () => {
            const heroSection = document.querySelector('.hero-container');
            if (!heroSection) return;
            
            // Create floating particles with enhanced colors
            for (let i = 0; i < 20; i++) {
                const particle = document.createElement('div');
                particle.className = 'floating-particle';
                particle.style.cssText = `
                    position: absolute;
                    width: ${Math.random() * 8 + 4}px;
                    height: ${Math.random() * 8 + 4}px;
                    background: linear-gradient(45deg, #60a5fa, #a78bfa, #f472b6, #34d399);
                    border-radius: 50%;
                    left: ${Math.random() * 100}%;
                    top: ${Math.random() * 100}%;
                    opacity: ${Math.random() * 0.8 + 0.2};
                    animation: float ${Math.random() * 6 + 4}s ease-in-out infinite alternate;
                    z-index: 1;
                    box-shadow: 0 0 20px rgba(96, 165, 250, 0.6);
                `;
                heroSection.appendChild(particle);
            }
            
            // Create geometric shapes with enhanced colors
            for (let i = 0; i < 8; i++) {
                const shape = document.createElement('div');
                shape.className = 'floating-shape';
                const isCircle = Math.random() > 0.5;
                shape.style.cssText = `
                    position: absolute;
                    width: ${Math.random() * 60 + 40}px;
                    height: ${Math.random() * 60 + 40}px;
                    background: linear-gradient(135deg, rgba(96, 165, 250, 0.3), rgba(167, 139, 250, 0.3), rgba(244, 114, 182, 0.3));
                    border: 2px solid rgba(96, 165, 250, 0.5);
                    ${isCircle ? 'border-radius: 50%;' : 'border-radius: 12px; transform: rotate(45deg);'}
                    left: ${Math.random() * 100}%;
                    top: ${Math.random() * 100}%;
                    animation: float ${Math.random() * 6 + 5}s ease-in-out infinite alternate;
                    z-index: 1;
                    box-shadow: 0 0 15px rgba(96, 165, 250, 0.4);
                `;
                heroSection.appendChild(shape);
            }
        };
        
        // Add CSS animations
        const style = document.createElement('style');
        style.textContent = `
            @keyframes float {
                0% { transform: translateY(0px) translateX(0px) rotate(0deg); }
                100% { transform: translateY(-20px) translateX(10px) rotate(10deg); }
            }
            @keyframes pulse-glow {
                0%, 100% { box-shadow: 0 0 25px rgba(96, 165, 250, 0.5); }
                50% { box-shadow: 0 0 50px rgba(167, 139, 250, 0.8); }
            }
            @keyframes gradient-shift {
                0% { background-position: 0% 50%; }
                50% { background-position: 100% 50%; }
                100% { background-position: 0% 50%; }
            }
            @keyframes tech-rotate {
                0% { transform: translateY(0px) rotate(0deg); }
                50% { transform: translateY(-10px) rotate(5deg); }
                100% { transform: translateY(0px) rotate(0deg); }
            }
            @keyframes rotate1 {
                from { transform: rotateX(50deg) rotateZ(110deg); }
                to { transform: rotateX(50deg) rotateZ(470deg); }
            }
            @keyframes rotate2 {
                from { transform: rotateX(20deg) rotateY(50deg) rotateZ(20deg); }
                to { transform: rotateX(20deg) rotateY(50deg) rotateZ(380deg); }
            }
            @keyframes rotate3 {
                from { transform: rotateX(40deg) rotateY(130deg) rotateZ(450deg); }
                to { transform: rotateX(40deg) rotateY(130deg) rotateZ(90deg); }
            }
            @keyframes rotate4 {
                from { transform: rotateX(70deg) rotateZ(270deg); }
                to { transform: rotateX(70deg) rotateZ(630deg); }
            }
            @keyframes slide-in-left {
                0% { transform: translateX(-100px); opacity: 0; }
                100% { transform: translateX(0); opacity: 1; }
            }
            @keyframes slide-in-right {
                0% { transform: translateX(100px); opacity: 0; }
                100% { transform: translateX(0); opacity: 1; }
            }
            @keyframes fade-in-up {
                0% { transform: translateY(30px); opacity: 0; }
                100% { transform: translateY(0); opacity: 1; }
            }
            .tech-tag-animate {
                animation: tech-rotate 2s ease-in-out infinite;
            }
            .orbit-container {
                position: relative;
                width: 100%;
                height: 100%;
            }
            .orbit-tag {
                position: absolute;
                transform-origin: center;
                will-change: transform;
            }
            @media (max-width: 768px) {
                .hero-rings {
                    width: 450px !important;
                    height: 450px !important;
                }
                .hero-ring {
                    width: 450px !important;
                    height: 450px !important;
                    border-bottom-width: 12px !important;
                }
                .hero-image-container {
                    width: 320px !important;
                    height: 320px !important;
                }
            }
            @media (max-width: 480px) {
                .hero-rings {
                    width: 360px !important;
                    height: 360px !important;
                }
                .hero-ring {
                    width: 360px !important;
                    height: 360px !important;
                    border-bottom-width: 10px !important;
                }
                .hero-image-container {
                    width: 260px !important;
                    height: 260px !important;
                }
            }
        `;
        document.head.appendChild(style);
        
        createFloatingElements();
        
        return () => {
            clearTimeout(timer);
            clearInterval(techInterval);
            window.removeEventListener('mousemove', handleMouseMove);
            if (document.head.contains(style)) {
                document.head.removeChild(style);
            }
        };
    }, [techTags.length]);
    
    return (
        <section className="relative min-h-screen bg-gradient-to-br from-blue-50 via-indigo-100 to-purple-100 overflow-hidden">
            {/* Enhanced Background Elements */}
            <div className="hero-container absolute inset-0"></div>
            
            {/* Animated Background Gradient with enhanced effects */}
            <div 
                className="absolute inset-0 opacity-40"
                style={{
                    background: `radial-gradient(circle at ${mousePosition.x}% ${mousePosition.y}%, rgba(96, 165, 250, 0.4) 0%, rgba(167, 139, 250, 0.3) 30%, rgba(244, 114, 182, 0.2) 60%, transparent 80%)`
                }}
            ></div>
            
            {/* Enhanced Grid Pattern */}
            <div className="absolute inset-0 opacity-20">
                <div className="absolute inset-0" style={{
                    backgroundImage: `linear-gradient(rgba(96, 165, 250, 0.4) 2px, transparent 2px),
                                     linear-gradient(90deg, rgba(96, 165, 250, 0.4) 2px, transparent 2px)`,
                    backgroundSize: '60px 60px'
                }}></div>
            </div>
            
            {/* Main Content Container with enhanced spacing */}
            <div className="relative z-10 container mx-auto px-4 sm:px-6 lg:px-8">
                {/* Content wrapper with enhanced header offset */}
                <div className="pt-28 sm:pt-32 md:pt-36 lg:pt-40 xl:pt-44 pb-16 sm:pb-20 md:pb-24">
                    <div className="flex flex-col lg:flex-row items-center justify-between min-h-[calc(100vh-14rem)]">
                        
                        {/* Left Content - Enhanced */}
                        <div className={`w-full lg:w-1/2 space-y-8 sm:space-y-10 md:space-y-12 transform transition-all duration-1200 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
                            
                            {/* Main Title - Enhanced with better animations and orbiting tech tags */}
                            <div className="space-y-4 sm:space-y-6 relative -mt-8 sm:-mt-12">
                                <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl xl:text-8xl font-black leading-tight relative">
                                    <span className="block bg-gradient-to-r from-gray-900 via-blue-700 to-purple-700 bg-clip-text text-transparent drop-shadow-lg animate-fade-in-up">
                                        {t('hero.title.line1') || 'Transform Your Future with'}
                                    </span>
                                    <span className="block relative mt-3 sm:mt-4">
                                        <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent animate-pulse drop-shadow-xl">
                                            {t('hero.title.highlight') || 'Technology'}
                                        </span>
                                        <div className="absolute -inset-2 bg-gradient-to-r from-blue-400 to-purple-400 blur-3xl opacity-40 animate-pulse"></div>
                                    </span>
                                    <span className="block bg-gradient-to-r from-gray-900 via-blue-700 to-purple-700 bg-clip-text text-transparent drop-shadow-lg animate-fade-in-up mt-3 sm:mt-4">
                                        {t('hero.title.line2') || 'Education'}
                                    </span>
                                </h1>
                                
                            </div>
                            
                            {/* Description - Enhanced with better typography */}
                            <p className="text-lg sm:text-xl md:text-2xl lg:text-3xl text-gray-700 leading-relaxed font-medium max-w-3xl animate-fade-in-up" style={{animationDelay: '0.2s'}}>
                                {t('hero.description') || 'Join thousands of students mastering cutting-edge technologies. Start your journey to a successful tech career today.'}
                            </p>
                            
                            {/* CTA Buttons - Enhanced with better effects */}
                            <div className="flex flex-col sm:flex-row gap-4 sm:gap-6 pt-6 sm:pt-8 animate-fade-in-up" style={{animationDelay: '0.4s'}}>
                                <Link 
                                    to="/courses" 
                                    className="group relative px-8 sm:px-10 py-4 sm:py-5 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-2xl sm:rounded-3xl font-bold text-base sm:text-lg lg:text-xl shadow-2xl hover:shadow-blue-400/50 transform hover:-translate-y-2 transition-all duration-400 overflow-hidden"
                                >
                                    <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-purple-700 opacity-0 group-hover:opacity-100 transition-opacity duration-400"></div>
                                    <div className="relative flex items-center justify-center space-x-3">
                                        <span>{t('hero.buttons.explorePrograms') || 'Explore Programs'}</span>
                                        <svg className="w-5 h-5 sm:w-6 sm:h-6 group-hover:translate-x-2 transition-transform duration-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                                        </svg>
                                    </div>
                                </Link>
                                
                                <Link 
                                    to="/apply" 
                                    className="group px-8 sm:px-10 py-4 sm:py-5 border-3 border-blue-500 text-blue-700 bg-white/90 rounded-2xl sm:rounded-3xl font-bold text-base sm:text-lg lg:text-xl backdrop-blur-md hover:bg-blue-50 hover:border-blue-600 hover:shadow-2xl transform hover:-translate-y-2 transition-all duration-400"
                                >
                                    <span className="group-hover:text-blue-800 transition-colors duration-400">
                                        {t('hero.buttons.applyNow') || 'Apply Now'}
                                    </span>
                                </Link>
                            </div>
                            
                            {/* Enhanced Stats with better animations */}
                            <div className="grid grid-cols-3 gap-6 sm:gap-8 md:gap-10 pt-8 sm:pt-10 border-t-3 border-blue-200/70 animate-fade-in-up" style={{animationDelay: '0.6s'}}>
                                <div className="text-center group">
                                    <div className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent group-hover:scale-125 transition-transform duration-400 drop-shadow-lg">
                                        93%
                                    </div>
                                    <div className="text-gray-700 text-sm sm:text-base md:text-lg mt-2 font-bold">
                                        {t('hero.stats.jobPlacement') || 'Job Placement'}
                                    </div>
                                </div>
                                
                                <div className="text-center group">
                                    <div className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent group-hover:scale-125 transition-transform duration-400 drop-shadow-lg">
                                        50+
                                    </div>
                                    <div className="text-gray-700 text-sm sm:text-base md:text-lg mt-2 font-bold">
                                        {t('hero.stats.industryPartners') || 'Partners'}
                                    </div>
                                </div>
                                
                                <div className="text-center group">
                                    <div className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold bg-gradient-to-r from-pink-600 to-blue-600 bg-clip-text text-transparent group-hover:scale-125 transition-transform duration-400 drop-shadow-lg">
                                        15+
                                    </div>
                                    <div className="text-gray-700 text-sm sm:text-base md:text-lg mt-2 font-bold">
                                        {t('hero.stats.yearsExcellence') || 'Years'}
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        {/* Right Content - Enhanced Image Section with Centered Rings */}
                        <div className={`w-full lg:w-1/2 mt-8 lg:mt-0 lg:pl-10 xl:pl-20 transform transition-all duration-1200 delay-500 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
                            <div className="relative group max-w-2xl mx-auto lg:max-w-none flex items-center justify-center -mt-8 lg:-mt-16">
                                
                                {/* Rotating Rings Container - Centered behind image */}
                                <div className="absolute flex items-center justify-center pointer-events-none" style={{
                                    width: '600px',
                                    height: '600px',
                                    zIndex: 1
                                }}>
                                    <div className="hero-rings relative" style={{
                                        width: '600px',
                                        height: '600px',
                                        display: 'flex',
                                        justifyContent: 'center',
                                        alignItems: 'center',
                                        perspective: '800px'
                                    }}>
                                        {/* Ring 1 - Pink */}
                                        <div className="hero-ring" style={{
                                            width: '600px',
                                            height: '600px',
                                            border: '1px solid transparent',
                                            borderRadius: '50%',
                                            position: 'absolute',
                                            borderBottom: '14px solid rgb(255, 141, 249)',
                                            animation: 'rotate1 2s linear infinite'
                                        }}></div>
                                        
                                        {/* Ring 2 - Red */}
                                        <div className="hero-ring" style={{
                                            width: '600px',
                                            height: '600px',
                                            border: '1px solid transparent',
                                            borderRadius: '50%',
                                            position: 'absolute',
                                            borderBottom: '14px solid rgb(255, 65, 106)',
                                            animation: 'rotate2 2s linear infinite'
                                        }}></div>
                                        
                                        {/* Ring 3 - Cyan */}
                                        <div className="hero-ring" style={{
                                            width: '600px',
                                            height: '600px',
                                            border: '1px solid transparent',
                                            borderRadius: '50%',
                                            position: 'absolute',
                                            borderBottom: '14px solid rgb(0, 255, 255)',
                                            animation: 'rotate3 2s linear infinite'
                                        }}></div>
                                        
                                        {/* Ring 4 - Orange */}
                                        <div className="hero-ring" style={{
                                            width: '600px',
                                            height: '600px',
                                            border: '1px solid transparent',
                                            borderRadius: '50%',
                                            position: 'absolute',
                                            borderBottom: '14px solid rgb(252, 183, 55)',
                                            animation: 'rotate4 2s linear infinite'
                                        }}></div>
                                    </div>
                                </div>
                                
                                {/* Circular Image Container - Inside the rotating rings */}
                                <div className="hero-image-container relative overflow-hidden bg-gradient-to-br from-blue-200/50 to-purple-200/50 backdrop-blur-sm border-4 border-white/80 shadow-3xl group-hover:shadow-blue-400/40 transition-all duration-600 z-10" style={{
                                    width: '480px',
                                    height: '480px',
                                    borderRadius: '50%',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center'
                                }}>
                                    
                                    {/* Circular Glow Effect */}
                                    <div className="absolute -inset-2 bg-gradient-to-r from-blue-400 to-purple-500 rounded-full blur-2xl opacity-40 group-hover:opacity-60 transition-opacity duration-600"></div>
                                    
                                    {/* Circular Image */}
                                    <div className="relative w-full h-full flex items-center justify-center" style={{
                                        borderRadius: '50%',
                                        overflow: 'hidden'
                                    }}>
                                        <img 
                                            src={heroImage} 
                                            alt={t('hero.imageAlt') || 'Technology Education'}
                                            className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-600"
                                            style={{
                                                borderRadius: '50%'
                                            }}
                                        />
                                        
                                        {/* Circular Image Overlay */}
                                        <div className="absolute inset-0 bg-gradient-to-t from-blue-200/30 via-transparent to-transparent rounded-full"></div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            {/* Enhanced Bottom Gradient */}
            <div className="absolute bottom-0 left-0 right-0 h-32 sm:h-40 bg-gradient-to-t from-blue-50 to-transparent"></div>
        </section>
    );
};

export default Hero;