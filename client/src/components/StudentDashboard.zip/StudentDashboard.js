import React, { useState, useEffect } from "react";
import { useHistory } from "react-router-dom";
import { useTranslation } from "react-i18next";
import "../styles/AdminSidebar.css";
import "../styles/Dashboard.css";
import ZoomMeetingCard from "./ZoomMeetingCard";

// Ant Design imports
import {
  Layout,
  Menu,
  Card,
  Table,
  Button,
  Form,
  Input,
  Upload,
  Modal,
  Select,
  Tabs,
  Progress,
  notification,
  Tag,
  Space,
  Divider,
  Row,
  Col,
  Statistic,
  DatePicker,
  Switch,
  InputNumber,
  Spin,
  Alert,
  Typography,
  Rate,
  Drawer,
  Breadcrumb,
  Empty,
  List,
  Timeline,
  Tooltip,
  Avatar,
  Badge,
  Popconfirm,
  message,
  Descriptions,
  Steps,
  Collapse,
  Calendar,
  Radio,
} from "antd";

import {
  PlusOutlined,
  EditOutlined,
  DeleteOutlined,
  UploadOutlined,
  DownloadOutlined,
  FileOutlined,
  VideoCameraOutlined,
  AudioOutlined,
  QuestionCircleOutlined,
  CheckCircleOutlined,
  CloseCircleOutlined,
  EyeOutlined,
  SearchOutlined,
  FilterOutlined,
  BookOutlined,
  FileTextOutlined,
  PlayCircleOutlined,
  HomeOutlined,
  UserOutlined,
  BarChartOutlined,
  CalendarOutlined,
  BellOutlined,
  SettingOutlined,
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  StarOutlined,
  ClockCircleOutlined,
  TrophyOutlined,
  MessageOutlined,
  TeamOutlined,
  LogoutOutlined,
  ReadOutlined,
  CheckSquareOutlined,
  LineChartOutlined,
  RocketOutlined,
  FireOutlined,
  HeartOutlined,
  LikeOutlined,
  CrownOutlined,
  SoundOutlined,
  FormOutlined,
  FieldTimeOutlined,
  ExclamationCircleOutlined,
} from "@ant-design/icons";

// Import API client
import { authAPI, statsAPI } from "../utils/apiClient";
import moment from "moment";

const { Header, Sider, Content } = Layout;
const { Title, Text, Paragraph } = Typography;
const { TabPane } = Tabs;

const StudentDashboard = () => {
  const { t } = useTranslation();
  const history = useHistory();

  // States
  const [collapsed, setCollapsed] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
  const [dashboardStats, setDashboardStats] = useState({
    enrolledCourses: 0,
    completedQuizzes: 0,
    totalAssignments: 0,
    overallGrade: 0,
    studyStreak: 0,
    certificatesEarned: 0,
  });

  // New states for integrated features
  const [listeningExercises, setListeningExercises] = useState([]);
  const [quizzes, setQuizzes] = useState([]);
  const [homework, setHomework] = useState([]);
  const [progressRecords, setProgressRecords] = useState([]);
  const [selectedListening, setSelectedListening] = useState(null);
  const [selectedQuiz, setSelectedQuiz] = useState(null);
  const [selectedHomework, setSelectedHomework] = useState(null);
  const [listeningModalVisible, setListeningModalVisible] = useState(false);
  const [quizModalVisible, setQuizModalVisible] = useState(false);
  const [homeworkModalVisible, setHomeworkModalVisible] = useState(false);
  const [submissionModalVisible, setSubmissionModalVisible] = useState(false);
  const [submissionForm] = Form.useForm();
  const [selectedAnswers, setSelectedAnswers] = useState({});
  const [submittingListening, setSubmittingListening] = useState(false);
  
  // Zoom Integration States
  const [zoomClasses, setZoomClasses] = useState([]);
  const [zoomNotifications, setZoomNotifications] = useState([]);
  const [zoomLoading, setZoomLoading] = useState(false);
  const [joinZoomModalVisible, setJoinZoomModalVisible] = useState(false);
  const [selectedZoomClass, setSelectedZoomClass] = useState(null);
  const [attendanceRecorded, setAttendanceRecorded] = useState(false);

  // Responsive handler
  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth <= 768;
      setIsMobile(mobile);
      // Auto-collapse on mobile
      if (mobile) {
        setCollapsed(true);
      }
    };

    window.addEventListener("resize", handleResize);
    handleResize(); // Initial check

    return () => window.removeEventListener("resize", handleResize);
  }, []);

  // Check authentication and user role
  useEffect(() => {
    const checkAuth = () => {
      const token =
        localStorage.getItem("authToken") || localStorage.getItem("token");
      const userRole = localStorage.getItem("userRole");
      const userEmail = localStorage.getItem("userEmail");
      const userName = localStorage.getItem("userName");
      const userId = localStorage.getItem("userId");

      if (!token || !userRole) {
        history.push("/login");
        return;
      }

      // Check if user has student permissions
      if (
        !["student", "teacher", "faculty", "admin", "superadmin"].includes(
          userRole
        )
      ) {
        message.error("Access denied. Student role required.");
        history.push("/");
        return;
      }

      // Create user object from stored data
      const userData = {
        id: userId,
        email: userEmail,
        role: userRole,
        name: userName,
      };

      setCurrentUser(userData);

      // Fetch all data
      Promise.all([
        fetchDashboardStats(),
        fetchListeningExercises(),
        fetchQuizzes(),
        fetchHomework(),
        fetchProgress(),
        fetchZoomClasses(),
        fetchZoomNotifications(),
      ]).finally(() => {
        setLoading(false);
      });
    };

    checkAuth();
  }, [history]);

  const fetchDashboardStats = async () => {
    try {
      console.log("🔄 Starting to fetch student dashboard stats...");
      const stats = await statsAPI.getStudentStats();
      console.log("✅ Received student stats:", stats);
      setDashboardStats(stats);
    } catch (error) {
      console.error("❌ Error fetching student stats:", error);
      // Set fallback data
      setDashboardStats({
        enrolledCourses: 3,
        completedQuizzes: 12,
        totalAssignments: 8,
        overallGrade: 85,
        studyStreak: 7,
        certificatesEarned: 2,
      });
    }
  };

  // Fetch listening exercises
  const fetchListeningExercises = async () => {
    try {
      const token =
        localStorage.getItem("authToken") || localStorage.getItem("token");

      if (!token) {
        console.error("❌ No authentication token found");
        message.error("Please login again");
        history.push("/login");
        return;
      }

      console.log(
        "🔄 Fetching listening exercises from:",
        `${process.env.REACT_APP_API_URL}/api/listening-exercises`
      );
      console.log("🔑 Using token:", token ? "Token exists" : "No token");

      const response = await fetch(
        `${process.env.REACT_APP_API_URL}/api/listening-exercises`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );

      console.log("📡 Response status:", response.status);
      console.log("📡 Response OK:", response.ok);

      if (response.status === 401) {
        console.error("❌ Authentication failed - token expired or invalid");
        message.error("Your session has expired. Please login again.");
        localStorage.clear();
        history.push("/login");
        return;
      }

      if (response.ok) {
        const data = await response.json();
        console.log("📚 Listening Exercises Response:", data);
        console.log(
          "📚 Total exercises received:",
          Array.isArray(data) ? data.length : 0
        );

        // The API returns an array directly, not wrapped in an object
        const exercises = Array.isArray(data) ? data : [];

        // Log each exercise's publish status
        exercises.forEach((ex, index) => {
          console.log(`📋 Exercise ${index + 1}:`, {
            title: ex.title,
            isPublished: ex.isPublished,
            level: ex.level,
            course: ex.course?.title || ex.course?.name || "No course",
          });
        });

        // Filter only published exercises for students
        const publishedExercises = exercises.filter(
          (ex) => ex.isPublished === true
        );
        console.log(
          "✅ Published Listening Exercises:",
          publishedExercises.length
        );
        console.log("✅ Published exercises data:", publishedExercises);
        setListeningExercises(publishedExercises);
      } else {
        console.error(
          "❌ Failed to fetch listening exercises:",
          response.status
        );
      }
    } catch (error) {
      console.error("❌ Error fetching listening exercises:", error);
    }
  };

  // Fetch quizzes
  const fetchQuizzes = async () => {
    try {
      const token =
        localStorage.getItem("authToken") || localStorage.getItem("token");

      if (!token) {
        console.error("❌ No authentication token found");
        return;
      }

      const response = await fetch(
        `${process.env.REACT_APP_API_URL}/api/quizzes`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );

      if (response.status === 401) {
        console.error("❌ Authentication failed for quizzes");
        return;
      }

      if (response.ok) {
        const data = await response.json();
        console.log("📝 Quizzes Response:", data);
        // The API returns an array directly, not wrapped in an object
        const quizList = Array.isArray(data) ? data : [];
        // Filter only published quizzes
        const publishedQuizzes = quizList.filter((q) => q.isPublished === true);
        console.log("✅ Published Quizzes:", publishedQuizzes.length);
        setQuizzes(publishedQuizzes);
      } else {
        console.error("❌ Failed to fetch quizzes:", response.status);
      }
    } catch (error) {
      console.error("❌ Error fetching quizzes:", error);
    }
  };

  // Fetch homework
  const fetchHomework = async () => {
    try {
      const token =
        localStorage.getItem("authToken") || localStorage.getItem("token");

      if (!token) {
        console.error("❌ No authentication token found");
        return;
      }

      const response = await fetch(
        `${process.env.REACT_APP_API_URL}/api/homework`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );

      if (response.status === 401) {
        console.error("❌ Authentication failed for homework");
        return;
      }

      if (response.ok) {
        const data = await response.json();
        console.log("📋 Homework Response:", data);
        // The API returns an array directly, not wrapped in an object
        const homeworkList = Array.isArray(data) ? data : [];
        // Filter only published homework
        const publishedHomework = homeworkList.filter(
          (hw) => hw.isPublished === true
        );
        console.log("✅ Published Homework:", publishedHomework.length);
        setHomework(publishedHomework);
      } else {
        console.error("❌ Failed to fetch homework:", response.status);
      }
    } catch (error) {
      console.error("❌ Error fetching homework:", error);
    }
  };

  // Fetch progress records
  const fetchProgress = async () => {
    try {
      const token =
        localStorage.getItem("authToken") || localStorage.getItem("token");

      if (!token) {
        console.error("❌ No authentication token found");
        return;
      }

      const response = await fetch(
        `${process.env.REACT_APP_API_URL}/api/progress`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );

      if (response.status === 401) {
        console.error("❌ Authentication failed for progress");
        return;
      }

      if (response.ok) {
        const result = await response.json();
        console.log("🏆 Progress Response:", result);
        // Check if result has progress property or is array directly
        const progressList = result.progress
          ? result.progress
          : Array.isArray(result)
          ? result
          : [];
        console.log("✅ Progress Records:", progressList.length);
        setProgressRecords(progressList);
      } else {
        console.error("❌ Failed to fetch progress:", response.status);
      }
    } catch (error) {
      console.error("❌ Error fetching progress:", error);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("authToken");
    localStorage.removeItem("token");
    localStorage.removeItem("userRole");
    localStorage.removeItem("userEmail");
    localStorage.removeItem("userName");
    localStorage.removeItem("userId");
    message.success("Logged out successfully");
    history.push("/");
  };

  // Zoom Integration Functions
  const fetchZoomClasses = async () => {
    try {
      setZoomLoading(true);
      console.log("📹 Fetching available Zoom classes for student...");
      
      // Simulate current student ID (in real app, this would come from auth context)
      const currentStudentId = "student1"; // This would be currentUser._id in real app
      
      // Fetch live classes specifically for this student
      const response = await fetch(`/api/zoom/meetings/student/${currentStudentId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const data = await response.json();
        
        if (data.success) {
          // Format the meetings for the UI
          const formattedClasses = data.meetings.map(meeting => ({
            id: meeting._id,
            title: meeting.title,
            courseName: meeting.courseName,
            meetingId: meeting.meetingId,
            password: meeting.meetingPassword,
            startTime: new Date(meeting.startTime),
            duration: meeting.duration,
            status: meeting.status === 'live' ? 'active' : meeting.status,
            teacherName: meeting.instructorName,
            joinUrl: meeting.joinUrl,
            description: meeting.description,
            isEnrolled: meeting.isEnrolled,
            settings: meeting.settings
          }));
          
          // Log access control results for debugging
          console.log("🔐 Access Control Results:");
          console.log(`📹 Total meetings available for student ${currentStudentId}: ${formattedClasses.length}`);
          formattedClasses.forEach(zoomClass => {
            console.log(`📹 ${zoomClass.title}: ✅ ENROLLED`);
          });

          setZoomClasses(formattedClasses);
        } else {
          throw new Error(data.message || 'Failed to fetch meetings');
        }
      } else {
        throw new Error('Failed to fetch live classes');
      }
    } catch (error) {
      console.error("❌ Error fetching Zoom classes:", error);
      message.error("Failed to fetch Zoom classes");
      setZoomClasses([]);
    } finally {
      setZoomLoading(false);
    }
  };

  const fetchZoomNotifications = async () => {
    try {
      console.log("📧 Fetching Zoom notifications...");
      // This would fetch notifications about Zoom classes
      const mockNotifications = [
        {
          id: "1",
          type: "zoom_class_started",
          title: "Live Class Started",
          message: "Your live class 'Introduction to Programming' has started. Click to join!",
          zoomClassId: "1",
          timestamp: new Date(),
          isRead: false
        }
      ];
      setZoomNotifications(mockNotifications);
    } catch (error) {
      console.error("❌ Error fetching Zoom notifications:", error);
    }
  };

  const handleJoinZoomClass = (zoomClass) => {
    if (!zoomClass.isAllowed) {
      message.error("You don't have permission to join this class. Please contact your teacher.");
      return;
    }

    if (zoomClass.status !== "active") {
      message.warning("This class is not currently active.");
      return;
    }

    setSelectedZoomClass(zoomClass);
    setJoinZoomModalVisible(true);
  };

  const handleConfirmJoinZoom = () => {
    if (selectedZoomClass) {
      // Record attendance automatically
      recordAttendance(selectedZoomClass);
      
      // Open Zoom link in new tab
      window.open(selectedZoomClass.joinUrl, '_blank');
      message.success("Opening Zoom class... Attendance recorded!");
      setJoinZoomModalVisible(false);
      setSelectedZoomClass(null);
    }
  };

  // Record attendance when student joins
  const recordAttendance = async (zoomClass) => {
    try {
      const attendanceData = {
        studentId: "student1", // This would be currentUser._id in real app
        studentName: "John Doe", // This would be currentUser.name in real app
        zoomClassId: zoomClass.id,
        joinTime: new Date(),
        status: 'present'
      };

      console.log("📝 Recording attendance:", attendanceData);
      
      // In a real app, this would send to the backend
      // await attendanceAPI.record(attendanceData);
      
      setAttendanceRecorded(true);
      
      // Show success notification
      notification.success({
        message: "Attendance Recorded",
        description: `Your attendance has been automatically recorded for ${zoomClass.title}`,
        duration: 4,
      });
      
    } catch (error) {
      console.error("❌ Error recording attendance:", error);
      message.error("Failed to record attendance");
    }
  };

  const markZoomNotificationAsRead = async (notificationId) => {
    try {
      const updatedNotifications = zoomNotifications.map(notification =>
        notification.id === notificationId
          ? { ...notification, isRead: true }
          : notification
      );
      setZoomNotifications(updatedNotifications);
    } catch (error) {
      console.error("❌ Error marking notification as read:", error);
    }
  };

  const studentMenuItems = [
    {
      key: "overview",
      icon: <HomeOutlined />,
      label: "Dashboard Overview",
    },
    {
      key: "listening",
      icon: <SoundOutlined />,
      label: "Listening Exercises",
    },
    {
      key: "quizzes",
      icon: <QuestionCircleOutlined />,
      label: "Quizzes",
    },
    {
      key: "homework",
      icon: <FormOutlined />,
      label: "Homework",
    },
    {
      key: "zoom",
      icon: <VideoCameraOutlined />,
      label: "Live Classes",
    },
    {
      key: "progress",
      icon: <TrophyOutlined />,
      label: "My Grades & Progress",
    },
    {
      key: "courses",
      icon: <BookOutlined />,
      label: "My Courses",
    },
    {
      key: "calendar",
      icon: <CalendarOutlined />,
      label: "Study Calendar",
    },
    {
      key: "achievements",
      icon: <CrownOutlined />,
      label: "Achievements",
    },
  ];

  const renderOverview = () => {
    const upcomingDeadlines = [
      ...homework.map((hw) => ({
        type: "homework",
        title: hw.title,
        dueDate: hw.dueDate,
        course: hw.course?.name,
      })),
      ...quizzes.map((q) => ({
        type: "quiz",
        title: q.title,
        dueDate: q.availableUntil,
        course: q.course?.name,
      })),
    ]
      .filter((item) => item.dueDate)
      .sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate))
      .slice(0, 5);

    return (
      <div style={{ padding: "24px" }}>
        <Title level={2}>
          <RocketOutlined style={{ marginRight: "12px", color: "#1890ff" }} />
          Student Dashboard
        </Title>
        <Text type="secondary" style={{ fontSize: "16px" }}>
          Welcome back, <Text strong>{currentUser?.name}</Text>! Let's continue
          your learning journey.
        </Text>

        {/* Statistics Cards */}
        <Row gutter={[16, 16]} style={{ marginTop: "32px" }}>
          <Col xs={24} sm={12} md={6}>
            <Card hoverable>
              <Statistic
                title="Active Listening Exercises"
                value={listeningExercises.length}
                prefix={<SoundOutlined style={{ color: "#1890ff" }} />}
                valueStyle={{ color: "#1890ff" }}
              />
            </Card>
          </Col>
          <Col xs={24} sm={12} md={6}>
            <Card hoverable>
              <Statistic
                title="Available Quizzes"
                value={quizzes.length}
                prefix={<QuestionCircleOutlined style={{ color: "#52c41a" }} />}
                valueStyle={{ color: "#52c41a" }}
              />
            </Card>
          </Col>
          <Col xs={24} sm={12} md={6}>
            <Card hoverable>
              <Statistic
                title="Pending Homework"
                value={homework.length}
                prefix={<FormOutlined style={{ color: "#faad14" }} />}
                valueStyle={{ color: "#faad14" }}
              />
            </Card>
          </Col>
          <Col xs={24} sm={12} md={6}>
            <Card hoverable>
              <Statistic
                title="My Grades"
                value={progressRecords.length}
                prefix={<TrophyOutlined style={{ color: "#f5222d" }} />}
                valueStyle={{ color: "#f5222d" }}
              />
            </Card>
          </Col>
        </Row>

        {/* Quick Access Cards */}
        <Row gutter={[16, 16]} style={{ marginTop: "24px" }}>
          <Col xs={24} md={8}>
            <Card
              title={
                <Space>
                  <SoundOutlined />
                  Listening Exercises
                </Space>
              }
              extra={
                <Button type="link" onClick={() => setActiveTab("listening")}>
                  View All
                </Button>
              }
              hoverable
            >
              {listeningExercises.length > 0 ? (
                <List
                  dataSource={listeningExercises.slice(0, 3)}
                  renderItem={(item) => (
                    <List.Item>
                      <List.Item.Meta
                        title={<Text strong>{item.title}</Text>}
                        description={
                          <Space direction="vertical" size={0}>
                            <Text type="secondary">
                              {item.course?.title || item.course?.name}
                            </Text>
                            <Text type="secondary">
                              <ClockCircleOutlined /> {item.timeLimit || "N/A"}{" "}
                              min • {item.questions?.length || 0} questions
                            </Text>
                          </Space>
                        }
                      />
                    </List.Item>
                  )}
                />
              ) : (
                <Empty description="No listening exercises available" />
              )}
            </Card>
          </Col>

          <Col xs={24} md={8}>
            <Card
              title={
                <Space>
                  <QuestionCircleOutlined />
                  Recent Quizzes
                </Space>
              }
              extra={
                <Button type="link" onClick={() => setActiveTab("quizzes")}>
                  View All
                </Button>
              }
              hoverable
            >
              {quizzes.length > 0 ? (
                <List
                  dataSource={quizzes.slice(0, 3)}
                  renderItem={(item) => (
                    <List.Item>
                      <List.Item.Meta
                        title={<Text strong>{item.title}</Text>}
                        description={
                          <Space direction="vertical" size={0}>
                            <Text type="secondary">{item.course?.name}</Text>
                            <Text type="secondary">
                              <FieldTimeOutlined /> {item.timeLimit} min •{" "}
                              {item.questions?.length || 0} questions
                            </Text>
                          </Space>
                        }
                      />
                    </List.Item>
                  )}
                />
              ) : (
                <Empty description="No quizzes available" />
              )}
            </Card>
          </Col>

          <Col xs={24} md={8}>
            <Card
              title={
                <Space>
                  <FormOutlined />
                  Homework
                </Space>
              }
              extra={
                <Button type="link" onClick={() => setActiveTab("homework")}>
                  View All
                </Button>
              }
              hoverable
            >
              {homework.length > 0 ? (
                <List
                  dataSource={homework.slice(0, 3)}
                  renderItem={(item) => (
                    <List.Item>
                      <List.Item.Meta
                        title={<Text strong>{item.title}</Text>}
                        description={
                          <Space direction="vertical" size={0}>
                            <Text type="secondary">{item.course?.name}</Text>
                            <Text type="secondary">
                              <CalendarOutlined /> Due:{" "}
                              {moment(item.dueDate).format("MMM DD, YYYY")}
                            </Text>
                          </Space>
                        }
                      />
                    </List.Item>
                  )}
                />
              ) : (
                <Empty description="No homework assignments" />
              )}
            </Card>
          </Col>
        </Row>

        {/* Upcoming Deadlines */}
        <Row gutter={[16, 16]} style={{ marginTop: "24px" }}>
          <Col xs={24} md={12}>
            <Card
              title={
                <Space>
                  <CalendarOutlined />
                  Upcoming Deadlines
                </Space>
              }
            >
              {upcomingDeadlines.length > 0 ? (
                <Timeline
                  items={upcomingDeadlines.map((item, index) => ({
                    key: index,
                    color:
                      moment(item.dueDate).diff(moment(), "days") <= 3
                        ? "red"
                        : "blue",
                    children: (
                      <>
                        <Text strong>{item.title}</Text>
                        <br />
                        <Text type="secondary">
                          {item.course} • Due:{" "}
                          {moment(item.dueDate).format("MMM DD, YYYY")}
                        </Text>
                        <br />
                        <Tag
                          color={item.type === "homework" ? "orange" : "blue"}
                        >
                          {item.type.toUpperCase()}
                        </Tag>
                      </>
                    ),
                  }))}
                />
              ) : (
                <Empty description="No upcoming deadlines" />
              )}
            </Card>
          </Col>

          <Col xs={24} md={12}>
            <Card
              title={
                <Space>
                  <RocketOutlined />
                  Quick Actions
                </Space>
              }
            >
              <Space
                direction="vertical"
                style={{ width: "100%" }}
                size="large"
              >
                <Button
                  type="primary"
                  size="large"
                  icon={<SoundOutlined />}
                  block
                  onClick={() => setActiveTab("listening")}
                >
                  Start Listening Exercise
                </Button>
                <Button
                  size="large"
                  icon={<QuestionCircleOutlined />}
                  block
                  onClick={() => setActiveTab("quizzes")}
                >
                  Take a Quiz
                </Button>
                <Button
                  size="large"
                  icon={<FormOutlined />}
                  block
                  onClick={() => setActiveTab("homework")}
                >
                  Submit Homework
                </Button>
                <Button
                  size="large"
                  icon={<TrophyOutlined />}
                  block
                  onClick={() => setActiveTab("progress")}
                >
                  View My Progress
                </Button>
              </Space>
            </Card>
          </Col>
        </Row>
      </div>
    );
  };

  // Render Listening Exercises Section
  const renderListeningExercises = () => {
    const columns = [
      {
        title: "Exercise Title",
        dataIndex: "title",
        key: "title",
        render: (text, record) => (
          <Space direction="vertical" size={0}>
            <Text strong>{text}</Text>
            <Text type="secondary">
              {record.course?.title || record.course?.name}
            </Text>
          </Space>
        ),
      },
      {
        title: "Difficulty",
        dataIndex: "level",
        key: "level",
        render: (level) => {
          const colors = {
            beginner: "green",
            intermediate: "orange",
            advanced: "red",
          };
          return <Tag color={colors[level]}>{level?.toUpperCase()}</Tag>;
        },
      },
      {
        title: "Duration",
        dataIndex: "timeLimit",
        key: "timeLimit",
        render: (timeLimit) => (
          <Text>
            <ClockCircleOutlined /> {timeLimit || "N/A"} min
          </Text>
        ),
      },
      {
        title: "Questions",
        dataIndex: "questions",
        key: "questions",
        render: (questions) => <Tag>{questions?.length || 0} Questions</Tag>,
      },
      {
        title: "Status",
        dataIndex: "isPublished",
        key: "isPublished",
        render: (isPublished) => (
          <Tag color={isPublished ? "success" : "default"}>
            {isPublished ? "PUBLISHED" : "DRAFT"}
          </Tag>
        ),
      },
      {
        title: "Actions",
        key: "actions",
        render: (_, record) => (
          <Button
            type="primary"
            icon={<PlayCircleOutlined />}
            onClick={() => {
              setSelectedListening(record);
              setListeningModalVisible(true);
            }}
          >
            Start Exercise
          </Button>
        ),
      },
    ];

    return (
      <div style={{ padding: "24px" }}>
        <Title level={2}>
          <SoundOutlined style={{ marginRight: "8px" }} />
          Listening Exercises
        </Title>
        <Text type="secondary">
          Practice your listening skills with interactive exercises
        </Text>

        <Card style={{ marginTop: "24px" }}>
          <Table
            columns={columns}
            dataSource={listeningExercises}
            rowKey="_id"
            pagination={{ pageSize: 10 }}
            locale={{ emptyText: "No listening exercises available" }}
          />
        </Card>
      </div>
    );
  };

  // Render Quizzes Section
  const renderQuizzes = () => {
    const columns = [
      {
        title: "Quiz Title",
        dataIndex: "title",
        key: "title",
        render: (text, record) => (
          <Space direction="vertical" size={0}>
            <Text strong>{text}</Text>
            <Text type="secondary">{record.course?.name}</Text>
          </Space>
        ),
      },
      {
        title: "Questions",
        dataIndex: "questions",
        key: "questions",
        render: (questions) => (
          <Tag color="blue">{questions?.length || 0} Questions</Tag>
        ),
      },
      {
        title: "Time Limit",
        dataIndex: "timeLimit",
        key: "timeLimit",
        render: (time) => (
          <Text>
            <FieldTimeOutlined /> {time} minutes
          </Text>
        ),
      },
      {
        title: "Passing Score",
        dataIndex: "passingScore",
        key: "passingScore",
        render: (score) => <Tag color="green">{score}%</Tag>,
      },
      {
        title: "Attempts",
        dataIndex: "maxAttempts",
        key: "maxAttempts",
        render: (attempts) => (
          <Text>{attempts === -1 ? "Unlimited" : `${attempts} attempts`}</Text>
        ),
      },
      {
        title: "Available Until",
        dataIndex: "availableUntil",
        key: "availableUntil",
        render: (date) =>
          date ? moment(date).format("MMM DD, YYYY") : "No deadline",
      },
      {
        title: "Actions",
        key: "actions",
        render: (_, record) => (
          <Button
            type="primary"
            icon={<PlayCircleOutlined />}
            onClick={() => {
              setSelectedQuiz(record);
              setQuizModalVisible(true);
            }}
          >
            Take Quiz
          </Button>
        ),
      },
    ];

    return (
      <div style={{ padding: "24px" }}>
        <Title level={2}>
          <QuestionCircleOutlined style={{ marginRight: "8px" }} />
          Practice Quizzes
        </Title>
        <Text type="secondary">
          Test your knowledge with interactive quizzes
        </Text>

        <Card style={{ marginTop: "24px" }}>
          <Table
            columns={columns}
            dataSource={quizzes}
            rowKey="_id"
            pagination={{ pageSize: 10 }}
            locale={{ emptyText: "No quizzes available" }}
          />
        </Card>
      </div>
    );
  };

  // Render Homework Section
  const renderHomework = () => {
    const columns = [
      {
        title: "Assignment",
        dataIndex: "title",
        key: "title",
        render: (text, record) => (
          <Space direction="vertical" size={0}>
            <Text strong>{text}</Text>
            <Text type="secondary">{record.course?.name}</Text>
          </Space>
        ),
      },
      {
        title: "Description",
        dataIndex: "description",
        key: "description",
        render: (text) => <Paragraph ellipsis={{ rows: 2 }}>{text}</Paragraph>,
      },
      {
        title: "Due Date",
        dataIndex: "dueDate",
        key: "dueDate",
        render: (date) => {
          const isOverdue = moment(date).isBefore(moment());
          return (
            <Space>
              <CalendarOutlined
                style={{ color: isOverdue ? "#ff4d4f" : "#1890ff" }}
              />
              <Text type={isOverdue ? "danger" : "secondary"}>
                {moment(date).format("MMM DD, YYYY")}
              </Text>
              {isOverdue && <Tag color="error">OVERDUE</Tag>}
            </Space>
          );
        },
      },
      {
        title: "Status",
        dataIndex: "status",
        key: "status",
        render: (status) => {
          const colors = {
            active: "success",
            draft: "default",
            archived: "warning",
          };
          return <Tag color={colors[status]}>{status?.toUpperCase()}</Tag>;
        },
      },
      {
        title: "Actions",
        key: "actions",
        render: (_, record) => (
          <Space>
            <Button
              type="primary"
              icon={<EyeOutlined />}
              onClick={() => {
                setSelectedHomework(record);
                setHomeworkModalVisible(true);
              }}
            >
              View Details
            </Button>
            <Button
              icon={<UploadOutlined />}
              onClick={() => {
                setSelectedHomework(record);
                setSubmissionModalVisible(true);
              }}
            >
              Submit
            </Button>
          </Space>
        ),
      },
    ];

    return (
      <div style={{ padding: "24px" }}>
        <Title level={2}>
          <FormOutlined style={{ marginRight: "8px" }} />
          Homework Assignments
        </Title>
        <Text type="secondary">View and submit your homework assignments</Text>

        <Card style={{ marginTop: "24px" }}>
          <Table
            columns={columns}
            dataSource={homework}
            rowKey="_id"
            pagination={{ pageSize: 10 }}
            locale={{ emptyText: "No homework assignments available" }}
          />
        </Card>
      </div>
    );
  };

  // Render Zoom Classes Section
  const renderZoomClasses = () => {

    return (
      <div style={{ padding: "24px" }}>
        <div
          style={{
            marginBottom: 32,
            padding: "24px",
            background: "linear-gradient(135deg, rgba(255, 255, 255, 0.9), rgba(255, 255, 255, 0.7))",
            borderRadius: "16px",
            backdropFilter: "blur(10px)",
            boxShadow: "0 8px 32px rgba(0, 0, 0, 0.08)",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
            <div
              style={{
                width: 48,
                height: 48,
                background: "linear-gradient(135deg, #dc2626 0%, #ea580c 100%)",
                borderRadius: "12px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                boxShadow: "0 4px 16px rgba(220, 38, 38, 0.3)",
              }}
            >
              <VideoCameraOutlined style={{ color: "#fff", fontSize: "20px" }} />
            </div>
            <div>
              <Title level={2} style={{ margin: 0, color: "#1f2937" }}>
                Live Classes
              </Title>
              <Text style={{ color: "#6b7280" }}>
                Join your live classes and interactive sessions
              </Text>
            </div>
          </div>
          <Badge count={zoomNotifications.filter(n => !n.isRead).length} overflowCount={99}>
            <Button
              type="primary"
              icon={<BellOutlined />}
              onClick={() => {
                // Show notifications
                const unreadNotifications = zoomNotifications.filter(n => !n.isRead);
                if (unreadNotifications.length > 0) {
                  notification.info({
                    message: "Live Class Notifications",
                    description: `You have ${unreadNotifications.length} new live class notifications`,
                    duration: 4,
                  });
                } else {
                  message.info("No new live class notifications");
                }
              }}
              style={{
                background: "linear-gradient(135deg, #dc2626 0%, #ea580c 100%)",
                border: "none",
                borderRadius: "10px",
                height: "40px",
                padding: "0 24px",
                fontWeight: 500,
              }}
            >
              Notifications
            </Button>
          </Badge>
        </div>

        {zoomLoading ? (
          <div style={{ textAlign: "center", padding: "40px" }}>
            <Spin size="large" />
            <div style={{ marginTop: "16px", color: "#666" }}>
              Loading live classes...
            </div>
          </div>
        ) : zoomClasses.length === 0 ? (
          <div style={{ textAlign: "center", padding: "40px" }}>
            <VideoCameraOutlined
              style={{ fontSize: "64px", color: "#d9d9d9", marginBottom: "16px" }}
            />
            <Title level={3} style={{ color: "#666" }}>
              No Live Classes Available
            </Title>
            <Text style={{ color: "#999" }}>
              You are not enrolled in any courses with live classes yet.
            </Text>
            <br />
            <Text style={{ color: "#999" }}>
              Contact your instructor to get access to live sessions.
            </Text>
          </div>
        ) : (
          <div>
            <div style={{ marginBottom: "16px" }}>
              <Text strong style={{ fontSize: "16px" }}>
                Your Live Classes ({zoomClasses.length})
              </Text>
            </div>
            {zoomClasses.map((meeting) => (
              <ZoomMeetingCard
                key={meeting.id}
                meeting={meeting}
                onJoinMeeting={handleJoinZoomClass}
              />
            ))}
          </div>
        )}

        {/* Join Zoom Modal */}
        <Modal
          title={
            <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
              <VideoCameraOutlined style={{ color: "#dc2626", fontSize: "20px" }} />
              <span>Join Live Class</span>
            </div>
          }
          open={joinZoomModalVisible}
          onCancel={() => {
            setJoinZoomModalVisible(false);
            setSelectedZoomClass(null);
          }}
          footer={null}
          width={500}
          className="modern-modal"
        >
          {selectedZoomClass && (
            <div style={{ marginTop: 24 }}>
              <div style={{ marginBottom: 24 }}>
                <Title level={4} style={{ marginBottom: 8 }}>
                  {selectedZoomClass.title}
                </Title>
                <Text style={{ color: "#666" }}>
                  {selectedZoomClass.courseName} • {selectedZoomClass.teacherName}
                </Text>
              </div>

              <div style={{ marginBottom: 24 }}>
                <Row gutter={16}>
                  <Col span={12}>
                    <Text strong>Meeting ID:</Text>
                    <br />
                    <Tag color="blue" style={{ fontFamily: "monospace", marginTop: 4 }}>
                      {selectedZoomClass.meetingId}
                    </Tag>
                  </Col>
                  <Col span={12}>
                    <Text strong>Password:</Text>
                    <br />
                    <Tag color="green" style={{ fontFamily: "monospace", marginTop: 4 }}>
                      {selectedZoomClass.password}
                    </Tag>
                  </Col>
                </Row>
              </div>

              <Alert
                message="Joining Live Class"
                description="Click 'Join Now' to open the Zoom class in a new tab. Your attendance will be automatically recorded when you join."
                type="info"
                showIcon
                style={{ marginBottom: 24 }}
              />

              {attendanceRecorded && (
                <Alert
                  message="Attendance Recorded"
                  description="Your attendance has been automatically recorded for this class."
                  type="success"
                  showIcon
                  style={{ marginBottom: 24 }}
                />
              )}

              <div style={{ textAlign: "right" }}>
                <Space>
                  <Button onClick={() => setJoinZoomModalVisible(false)}>
                    Cancel
                  </Button>
                  <Button
                    type="primary"
                    onClick={handleConfirmJoinZoom}
                    style={{
                      background: "linear-gradient(135deg, #dc2626 0%, #ea580c 100%)",
                      border: "none",
                    }}
                  >
                    Join Now
                  </Button>
                </Space>
              </div>
            </div>
          )}
        </Modal>
      </div>
    );
  };

  // Render Progress Section
  const renderProgress = () => {
    const columns = [
      {
        title: "Subject",
        dataIndex: "subject",
        key: "subject",
        render: (subject) => <Tag color="blue">{subject}</Tag>,
      },
      {
        title: "Assignment",
        dataIndex: "assignment",
        key: "assignment",
        render: (text) => <Text strong>{text}</Text>,
      },
      {
        title: "Type",
        dataIndex: "assignmentType",
        key: "assignmentType",
        render: (type) => {
          const colors = {
            homework: "orange",
            quiz: "blue",
            exam: "red",
            project: "purple",
          };
          return <Tag color={colors[type]}>{type?.toUpperCase()}</Tag>;
        },
      },
      {
        title: "Score",
        dataIndex: "score",
        key: "score",
        render: (score, record) => (
          <Space>
            <Text strong>
              {score}/{record.maxScore}
            </Text>
            <Text type="secondary">({record.percentage}%)</Text>
          </Space>
        ),
      },
      {
        title: "Grade",
        dataIndex: "grade",
        key: "grade",
        render: (grade) => {
          const getColor = (g) => {
            if (["A+", "A", "A-"].includes(g)) return "green";
            if (["B+", "B", "B-"].includes(g)) return "blue";
            if (["C+", "C", "C-"].includes(g)) return "orange";
            return "red";
          };
          return (
            <Tag color={getColor(grade)} style={{ fontWeight: "bold" }}>
              {grade}
            </Tag>
          );
        },
      },
      {
        title: "Date Graded",
        dataIndex: "gradedDate",
        key: "gradedDate",
        render: (date) => moment(date).format("MMM DD, YYYY"),
      },
      {
        title: "Teacher",
        dataIndex: "teacher",
        key: "teacher",
        render: (teacher) =>
          teacher ? `${teacher.firstName} ${teacher.lastName}` : "N/A",
      },
    ];

    const averageGrade =
      progressRecords.length > 0
        ? (
            progressRecords.reduce(
              (sum, record) => sum + record.percentage,
              0
            ) / progressRecords.length
          ).toFixed(1)
        : 0;

    return (
      <div style={{ padding: "24px" }}>
        <Title level={2}>
          <TrophyOutlined style={{ marginRight: "8px" }} />
          My Grades & Progress
        </Title>
        <Text type="secondary">Track your academic performance</Text>

        <Row gutter={[16, 16]} style={{ marginTop: "24px" }}>
          <Col xs={24} sm={8}>
            <Card>
              <Statistic
                title="Total Graded Assignments"
                value={progressRecords.length}
                prefix={<CheckCircleOutlined />}
              />
            </Card>
          </Col>
          <Col xs={24} sm={8}>
            <Card>
              <Statistic
                title="Average Score"
                value={averageGrade}
                suffix="%"
                prefix={<BarChartOutlined />}
                valueStyle={{
                  color:
                    averageGrade >= 80
                      ? "#52c41a"
                      : averageGrade >= 60
                      ? "#faad14"
                      : "#f5222d",
                }}
              />
            </Card>
          </Col>
          <Col xs={24} sm={8}>
            <Card>
              <Statistic
                title="Study Streak"
                value={dashboardStats.studyStreak || 0}
                suffix=" days"
                prefix={<FireOutlined />}
                valueStyle={{ color: "#722ed1" }}
              />
            </Card>
          </Col>
        </Row>

        <Card style={{ marginTop: "24px" }} title="Grade History">
          <Table
            columns={columns}
            dataSource={progressRecords}
            rowKey="_id"
            pagination={{ pageSize: 10 }}
            locale={{ emptyText: "No grades recorded yet" }}
          />
        </Card>
      </div>
    );
  };

  const renderCourses = () => (
    <div style={{ padding: "24px" }}>
      <Title level={2}>📚 My Courses</Title>
      <Text type="secondary">Continue your learning journey</Text>

      <Row gutter={[16, 16]} style={{ marginTop: "24px" }}>
        <Col xs={24} sm={12} md={8}>
          <Card
            hoverable
            cover={
              <div
                style={{
                  height: 120,
                  background:
                    "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
                }}
              />
            }
            actions={[
              <Button type="link">Continue</Button>,
              <Button type="link">View Materials</Button>,
            ]}
          >
            <Card.Meta
              title="Advanced English"
              description="Progress: 75% • Next: Grammar Lesson 5"
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={8}>
          <Card
            hoverable
            cover={
              <div
                style={{
                  height: 120,
                  background:
                    "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",
                }}
              />
            }
            actions={[
              <Button type="link">Continue</Button>,
              <Button type="link">View Materials</Button>,
            ]}
          >
            <Card.Meta
              title="Japanese 101"
              description="Progress: 45% • Next: Hiragana Practice"
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={8}>
          <Card
            hoverable
            cover={
              <div
                style={{
                  height: 120,
                  background:
                    "linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)",
                }}
              />
            }
            actions={[
              <Button type="link">Continue</Button>,
              <Button type="link">View Materials</Button>,
            ]}
          >
            <Card.Meta
              title="Spanish Basics"
              description="Progress: 90% • Next: Final Exam"
            />
          </Card>
        </Col>
      </Row>
    </div>
  );

  const renderAchievements = () => (
    <div style={{ padding: "24px" }}>
      <Title level={2}>🏆 Achievements</Title>
      <Text type="secondary">Your learning milestones and badges</Text>

      <Row gutter={[16, 16]} style={{ marginTop: "24px" }}>
        <Col xs={24} sm={12} md={8}>
          <Card>
            <div style={{ textAlign: "center" }}>
              <TrophyOutlined style={{ fontSize: "48px", color: "#faad14" }} />
              <Title level={4}>Quick Learner</Title>
              <Text type="secondary">Completed 10 lessons in one week</Text>
            </div>
          </Card>
        </Col>
        <Col xs={24} sm={12} md={8}>
          <Card>
            <div style={{ textAlign: "center" }}>
              <FireOutlined style={{ fontSize: "48px", color: "#f5222d" }} />
              <Title level={4}>7-Day Streak</Title>
              <Text type="secondary">Studied for 7 consecutive days</Text>
            </div>
          </Card>
        </Col>
        <Col xs={24} sm={12} md={8}>
          <Card>
            <div style={{ textAlign: "center" }}>
              <StarOutlined style={{ fontSize: "48px", color: "#722ed1" }} />
              <Title level={4}>Perfect Score</Title>
              <Text type="secondary">Scored 100% on a quiz</Text>
            </div>
          </Card>
        </Col>
      </Row>
    </div>
  );

  const renderContent = () => {
    return (
      <>
        <div style={{ display: activeTab === "overview" ? "block" : "none" }}>
          {renderOverview()}
        </div>
        <div style={{ display: activeTab === "listening" ? "block" : "none" }}>
          {renderListeningExercises()}
        </div>
        <div style={{ display: activeTab === "quizzes" ? "block" : "none" }}>
          {renderQuizzes()}
        </div>
        <div style={{ display: activeTab === "homework" ? "block" : "none" }}>
          {renderHomework()}
        </div>
        <div style={{ display: activeTab === "zoom" ? "block" : "none" }}>
          {renderZoomClasses()}
        </div>
        <div style={{ display: activeTab === "progress" ? "block" : "none" }}>
          {renderProgress()}
        </div>
        <div style={{ display: activeTab === "courses" ? "block" : "none" }}>
          {renderCourses()}
        </div>
        <div style={{ display: activeTab === "calendar" ? "block" : "none" }}>
          <div style={{ padding: "24px" }}>
            <Title level={2}>
              <CalendarOutlined style={{ marginRight: "8px" }} />
              Study Calendar
            </Title>
            <Calendar />
          </div>
        </div>
        <div
          style={{ display: activeTab === "achievements" ? "block" : "none" }}
        >
          {renderAchievements()}
        </div>
      </>
    );
  };

  if (loading) {
    return (
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "100vh",
        }}
      >
        <Spin size="large" />
      </div>
    );
  }

  // Handle listening exercise submission
  const handleListeningSubmission = async () => {
    try {
      if (!selectedListening) return;

      // Validate all questions are answered
      const totalQuestions = selectedListening.questions?.length || 0;
      const answeredQuestions = Object.keys(selectedAnswers).length;

      if (answeredQuestions < totalQuestions) {
        message.warning(
          `Please answer all ${totalQuestions} questions before submitting.`
        );
        return;
      }

      setSubmittingListening(true);
      const token =
        localStorage.getItem("authToken") || localStorage.getItem("token");

      console.log("📤 Submitting listening exercise...");
      console.log("Exercise ID:", selectedListening._id);
      console.log("Selected Answers:", selectedAnswers);
      console.log("Questions:", selectedListening.questions);

      const response = await fetch(
        `${process.env.REACT_APP_API_URL}/api/listening-exercises/${selectedListening._id}/submit`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            answers: selectedAnswers,
          }),
        }
      );

      if (response.ok) {
        const result = await response.json();
        message.success(
          `Exercise submitted successfully! Score: ${result.score}/${result.totalQuestions} (${result.percentage}%)`
        );
        setListeningModalVisible(false);
        setSelectedAnswers({});
        setSelectedListening(null);
        // Refresh progress
        fetchProgress();
      } else {
        const error = await response.json();
        message.error(error.message || "Failed to submit exercise");
      }
    } catch (error) {
      console.error("Error submitting listening exercise:", error);
      message.error("Error submitting exercise");
    } finally {
      setSubmittingListening(false);
    }
  };

  // Handle homework submission
  const handleHomeworkSubmission = async (values) => {
    try {
      const token = localStorage.getItem("token");
      const formData = new FormData();
      formData.append("homeworkId", selectedHomework._id);
      formData.append("content", values.content);
      if (values.file) {
        formData.append("file", values.file);
      }

      const response = await fetch(
        `${process.env.REACT_APP_API_URL}/api/homework-submissions`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
          },
          body: formData,
        }
      );

      if (response.ok) {
        message.success("Homework submitted successfully!");
        setSubmissionModalVisible(false);
        submissionForm.resetFields();
      } else {
        message.error("Failed to submit homework");
      }
    } catch (error) {
      console.error("Error submitting homework:", error);
      message.error("Error submitting homework");
    }
  };

  return (
    <Layout style={{ minHeight: "100vh" }}>
      {/* Listening Exercise Detail Modal */}
      <Modal
        title={
          <Space>
            <SoundOutlined />
            Listening Exercise Details
          </Space>
        }
        open={listeningModalVisible}
        onCancel={() => setListeningModalVisible(false)}
        footer={[
          <Button
            key="close"
            onClick={() => {
              setListeningModalVisible(false);
              setSelectedAnswers({});
            }}
          >
            Close
          </Button>,
          <Button
            key="submit"
            type="primary"
            icon={<CheckCircleOutlined />}
            loading={submittingListening}
            onClick={handleListeningSubmission}
            disabled={
              !selectedListening?.questions ||
              Object.keys(selectedAnswers).length <
                selectedListening?.questions?.length
            }
          >
            Submit Answers ({Object.keys(selectedAnswers).length}/
            {selectedListening?.questions?.length || 0})
          </Button>,
        ]}
        width={700}
      >
        {selectedListening && (
          <Space direction="vertical" size="large" style={{ width: "100%" }}>
            <Descriptions bordered column={2}>
              <Descriptions.Item label="Course" span={2}>
                <Tag color="blue">{selectedListening.course?.name}</Tag>
              </Descriptions.Item>
              <Descriptions.Item label="Difficulty">
                <Tag
                  color={
                    selectedListening.difficulty === "beginner"
                      ? "green"
                      : selectedListening.difficulty === "intermediate"
                      ? "orange"
                      : "red"
                  }
                >
                  {selectedListening.difficulty?.toUpperCase()}
                </Tag>
              </Descriptions.Item>
              <Descriptions.Item label="Duration">
                {selectedListening.duration || "N/A"} minutes
              </Descriptions.Item>
              <Descriptions.Item label="Questions" span={2}>
                {selectedListening.questions?.length || 0} questions
              </Descriptions.Item>
              <Descriptions.Item label="Description" span={2}>
                {selectedListening.description || "No description available"}
              </Descriptions.Item>
            </Descriptions>

            {selectedListening.audioUrl && (
              <>
                <Alert
                  message="Audio Available"
                  description="Listen to the audio file below and answer the questions."
                  type="success"
                  showIcon
                  icon={<AudioOutlined />}
                />
                <Card title="Audio Player" size="small">
                  <audio
                    controls
                    style={{ width: "100%" }}
                    src={selectedListening.audioUrl}
                  >
                    Your browser does not support the audio element.
                  </audio>
                </Card>
              </>
            )}

            {!selectedListening.audioUrl && (
              <Alert
                message="No Audio File"
                description="This exercise doesn't have an audio file yet."
                type="warning"
                showIcon
                icon={<ExclamationCircleOutlined />}
              />
            )}

            {selectedListening.questions &&
              selectedListening.questions.length > 0 && (
                <Card title="Questions" size="small">
                  <Space
                    direction="vertical"
                    style={{ width: "100%" }}
                    size="large"
                  >
                    {selectedListening.questions.map((question, index) => (
                      <Card key={index} type="inner" size="small">
                        <Space direction="vertical" style={{ width: "100%" }}>
                          <Text strong>
                            Question {index + 1}:{" "}
                            {question.questionText || question.question}
                          </Text>

                          {/* Question Type Badge */}
                          <Tag color="blue">
                            {question.type?.replace(/_/g, " ").toUpperCase() ||
                              "QUESTION"}
                          </Tag>

                          {/* Debug: Log question details */}
                          {console.log(`Question ${index + 1}:`, {
                            type: question.type,
                            hasOptions: !!question.options,
                            optionsLength: question.options?.length,
                            correctAnswer: question.correctAnswer,
                            options: question.options,
                          })}

                          {/* Multiple Choice Questions - Smart detection: if has options array, treat as multiple choice */}
                          {question.options && question.options.length > 0 && (
                            <Radio.Group
                              value={selectedAnswers[question._id]}
                              onChange={(e) => {
                                setSelectedAnswers({
                                  ...selectedAnswers,
                                  [question._id]: e.target.value,
                                });
                              }}
                              style={{ width: "100%" }}
                            >
                              <Space
                                direction="vertical"
                                style={{ width: "100%" }}
                              >
                                {question.options.map((option, optIndex) => (
                                  <Radio key={optIndex} value={optIndex}>
                                    <Text>
                                      {String.fromCharCode(65 + optIndex)}.{" "}
                                      {typeof option === "string"
                                        ? option
                                        : option.text || option}
                                    </Text>
                                  </Radio>
                                ))}
                              </Space>
                            </Radio.Group>
                          )}

                          {/* Fill in the Blank Questions */}
                          {question.type === "fill_in_blank" && (
                            <Input
                              placeholder="Type your answer here..."
                              value={selectedAnswers[question._id] || ""}
                              onChange={(e) => {
                                setSelectedAnswers({
                                  ...selectedAnswers,
                                  [question._id]: e.target.value,
                                });
                              }}
                              style={{ width: "100%" }}
                            />
                          )}

                          {/* Short Answer Questions */}
                          {question.type === "short_answer" && (
                            <Input.TextArea
                              rows={3}
                              placeholder="Type your answer here..."
                              value={selectedAnswers[question._id] || ""}
                              onChange={(e) => {
                                setSelectedAnswers({
                                  ...selectedAnswers,
                                  [question._id]: e.target.value,
                                });
                              }}
                              style={{ width: "100%" }}
                            />
                          )}

                          {/* True/False Questions */}
                          {question.type === "true_false" && (
                            <Radio.Group
                              value={selectedAnswers[question._id]}
                              onChange={(e) => {
                                setSelectedAnswers({
                                  ...selectedAnswers,
                                  [question._id]: e.target.value,
                                });
                              }}
                              style={{ width: "100%" }}
                            >
                              <Space direction="vertical">
                                <Radio value="true">True</Radio>
                                <Radio value="false">False</Radio>
                              </Space>
                            </Radio.Group>
                          )}

                          {/* Points indicator */}
                          <Text type="secondary" style={{ fontSize: "12px" }}>
                            Points: {question.points || 1}
                          </Text>
                        </Space>
                      </Card>
                    ))}
                  </Space>
                </Card>
              )}
          </Space>
        )}
      </Modal>

      {/* Quiz Detail Modal */}
      <Modal
        title={
          <Space>
            <QuestionCircleOutlined />
            Quiz Details
          </Space>
        }
        open={quizModalVisible}
        onCancel={() => setQuizModalVisible(false)}
        footer={[
          <Button key="close" onClick={() => setQuizModalVisible(false)}>
            Close
          </Button>,
          <Button
            key="start"
            type="primary"
            icon={<PlayCircleOutlined />}
            onClick={() => {
              message.info("Quiz interface will be implemented");
              // TODO: Implement quiz taking interface
            }}
          >
            Start Quiz
          </Button>,
        ]}
        width={700}
      >
        {selectedQuiz && (
          <Space direction="vertical" size="large" style={{ width: "100%" }}>
            <Descriptions bordered column={2}>
              <Descriptions.Item label="Course" span={2}>
                <Tag color="blue">{selectedQuiz.course?.name}</Tag>
              </Descriptions.Item>
              <Descriptions.Item label="Questions">
                {selectedQuiz.questions?.length || 0} questions
              </Descriptions.Item>
              <Descriptions.Item label="Time Limit">
                <FieldTimeOutlined /> {selectedQuiz.timeLimit} minutes
              </Descriptions.Item>
              <Descriptions.Item label="Passing Score">
                <Tag color="green">{selectedQuiz.passingScore}%</Tag>
              </Descriptions.Item>
              <Descriptions.Item label="Max Attempts">
                {selectedQuiz.maxAttempts === -1
                  ? "Unlimited"
                  : selectedQuiz.maxAttempts}
              </Descriptions.Item>
              <Descriptions.Item label="Available Until" span={2}>
                {selectedQuiz.availableUntil
                  ? moment(selectedQuiz.availableUntil).format("MMM DD, YYYY")
                  : "No deadline"}
              </Descriptions.Item>
            </Descriptions>

            <Alert
              message="Quiz Instructions"
              description="Read all questions carefully. You cannot go back once you submit an answer."
              type="info"
              showIcon
            />
          </Space>
        )}
      </Modal>

      {/* Homework Detail Modal */}
      <Modal
        title={
          <Space>
            <FormOutlined />
            Homework Details
          </Space>
        }
        open={homeworkModalVisible}
        onCancel={() => setHomeworkModalVisible(false)}
        footer={[
          <Button key="close" onClick={() => setHomeworkModalVisible(false)}>
            Close
          </Button>,
          <Button
            key="submit"
            type="primary"
            icon={<UploadOutlined />}
            onClick={() => {
              setHomeworkModalVisible(false);
              setSubmissionModalVisible(true);
            }}
          >
            Submit Homework
          </Button>,
        ]}
        width={700}
      >
        {selectedHomework && (
          <Space direction="vertical" size="large" style={{ width: "100%" }}>
            <Descriptions bordered column={2}>
              <Descriptions.Item label="Course" span={2}>
                <Tag color="blue">{selectedHomework.course?.name}</Tag>
              </Descriptions.Item>
              <Descriptions.Item label="Due Date" span={2}>
                <Space>
                  <CalendarOutlined />
                  <Text>
                    {moment(selectedHomework.dueDate).format("MMM DD, YYYY")}
                  </Text>
                  {moment(selectedHomework.dueDate).isBefore(moment()) && (
                    <Tag color="error">OVERDUE</Tag>
                  )}
                </Space>
              </Descriptions.Item>
              <Descriptions.Item label="Description" span={2}>
                {selectedHomework.description}
              </Descriptions.Item>
              <Descriptions.Item label="Instructions" span={2}>
                {selectedHomework.instructions ||
                  "No specific instructions provided"}
              </Descriptions.Item>
            </Descriptions>

            {selectedHomework.attachments?.length > 0 && (
              <Card title="Attachments" size="small">
                <List
                  dataSource={selectedHomework.attachments}
                  renderItem={(item) => (
                    <List.Item>
                      <FileOutlined /> {item}
                    </List.Item>
                  )}
                />
              </Card>
            )}
          </Space>
        )}
      </Modal>

      {/* Homework Submission Modal */}
      <Modal
        title={
          <Space>
            <UploadOutlined />
            Submit Homework
          </Space>
        }
        open={submissionModalVisible}
        onCancel={() => {
          setSubmissionModalVisible(false);
          submissionForm.resetFields();
        }}
        footer={null}
        width={600}
      >
        <Form
          form={submissionForm}
          layout="vertical"
          onFinish={handleHomeworkSubmission}
        >
          <Alert
            message="Submission Guidelines"
            description="Please ensure your work is complete before submitting. Late submissions may affect your grade."
            type="warning"
            showIcon
            style={{ marginBottom: "24px" }}
          />

          <Form.Item
            label="Your Answer / Solution"
            name="content"
            rules={[{ required: true, message: "Please enter your answer" }]}
          >
            <Input.TextArea
              rows={6}
              placeholder="Type your homework answer here..."
            />
          </Form.Item>

          <Form.Item
            label="Attach File (Optional)"
            name="file"
            valuePropName="file"
          >
            <Upload maxCount={1} beforeUpload={() => false}>
              <Button icon={<UploadOutlined />}>Select File</Button>
            </Upload>
          </Form.Item>

          <Form.Item>
            <Space style={{ width: "100%", justifyContent: "flex-end" }}>
              <Button
                onClick={() => {
                  setSubmissionModalVisible(false);
                  submissionForm.resetFields();
                }}
              >
                Cancel
              </Button>
              <Button
                type="primary"
                htmlType="submit"
                icon={<CheckCircleOutlined />}
              >
                Submit Homework
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </Modal>

      <Sider
        trigger={null}
        collapsible
        collapsed={collapsed}
        width={250}
        style={{
          background: "#001529",
        }}
      >
        <div
          style={{
            height: "64px",
            margin: "16px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Title level={4} style={{ color: "#fff", margin: 0 }}>
            {collapsed ? "FA" : "Forum Academy"}
          </Title>
        </div>

        <Menu
          theme="dark"
          mode="inline"
          selectedKeys={[activeTab]}
          items={studentMenuItems}
          onClick={(e) => setActiveTab(e.key)}
        />
      </Sider>

      <Layout>
        <Header
          style={{
            padding: "0 24px",
            background: "#fff",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            boxShadow: "0 1px 4px rgba(0,21,41,.08)",
          }}
        >
          <Button
            type="text"
            icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
            onClick={() => setCollapsed(!collapsed)}
            style={{ fontSize: "16px", width: 64, height: 64 }}
          />

          <Space>
            <Badge count={3}>
              <Button type="text" icon={<BellOutlined />} />
            </Badge>
            <Avatar
              style={{ backgroundColor: "#87d068" }}
              icon={<UserOutlined />}
            />
            <Text strong>{currentUser?.name}</Text>
            <Button type="link" onClick={handleLogout}>
              Logout
            </Button>
          </Space>
        </Header>

        <Content
          style={{
            margin: "24px 16px",
            padding: 24,
            background: "#f0f2f5",
            minHeight: 280,
          }}
        >
          {renderContent()}
        </Content>
      </Layout>
    </Layout>
  );
};

export default StudentDashboard;
